# Overview

A Mancala Game has built using SpringBoot Application with a ReactJs interface, and MongoDb to persist resources.

# TechStack
  * Java17
  * SpringBoot 3.0.X
  * Maven
  * MongoDB
  * ReactJS
  * Helm Chart(package manager for Kubernetes & Docker)
  
# Configuration
  * Install the Bring the MongoDB container and configure the same in application.properties
  * Configure the application urls in gateway properties file
  
# Running
 * The best way to run the application is to install helm chart in Kubernetes environment 
 * helm install will deploy all 4 services and bring the pod up
 * http://localhost:8080/swagger-ui/index.html - Swagger
 * http://localhost:8080/ - Gateway
 * http://localhost:8081/ - Game Service
 * http://localhost:8082/ - Player Service
 * http://localhost:8083/ - Rule Engine
 * http://localhost:3000/ - GUI

#Game Core
 * Contains all the common utilities, exceptions, dtos
 * It is a jar and non-executable file

#Player Service
 * Contains the business implementations for Players like Create etc
 * It runs as individual microservice

#Game Service
  * Contains the business implementations for Game like Start,Play,Move etc
  * It runs as individual microservice

#Rule Engine
  * Contains the business implementations for Rule engine like Validate etc
  * It runs as individual microservice

#GateWay
 * All the requests from GUI received by Gateway service and internally routed to difference services
 * When application evolves like paid game etc, we can implement security services as well

#GUI
  * Built using React JS with 3 different components like Game, Play etc

