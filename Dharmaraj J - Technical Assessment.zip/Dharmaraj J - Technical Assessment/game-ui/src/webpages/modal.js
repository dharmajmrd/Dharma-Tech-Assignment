import React, { useState, useEffect } from 'react';
import "./modal.css";
import { createPortal } from "react-dom";

const Modal = ({ show, close, title, children }) => {

const [domReady, setDomReady] = React.useState(false)

    useEffect(() => {
      setDomReady(true)
    }, [])
  return domReady?createPortal(
    <>
      <div
        className={`modalContainer ${show ? "show" : ""} `}
        onClick={() => close()}
      >
        <div className="modal" onClick={(e) => e.stopPropagation()}>
          <header className="modal_header">
            <span className="modal_header-title">{title}</span>
            <button className="close" onClick={() => close()}>
              X
            </button>
          </header>
          <main className="modal_content">{children}</main>
        </div>
      </div>
    </>,
    document.getElementById("modal")
  ):null;
};

export default Modal;