import { POST, JSON_CONTENT_TYPE, BASE_URL } from "../utils/constants.js";
import React, { useState, useEffect } from 'react';

import { useNavigate } from "react-router-dom";

const Game = () => {

    const [gameInfo, setGameInfo] = useState([]);

    const navigate = useNavigate();

    const url = `${BASE_URL}/start`;

    const gameStartRequest = {
        firstPlayer: {name : "Player1"},
        secondPlayer:{name : "Player2"}
  };

    useEffect(() => {
        fetch(url,{
            headers: {
              "Content-Type": JSON_CONTENT_TYPE
            },
            method: POST,
            body: JSON.stringify(gameStartRequest)})
           .then((response) => response.json())
           .then((data) => {
              console.log(data);
              setGameInfo(data);
              navigate("/play",{state:data}); 
           })
           .catch((err) => {
              console.log(err);
           });
     }, []);

return(
    <div className="container">
        
    </div>
    );
}
export default Game;