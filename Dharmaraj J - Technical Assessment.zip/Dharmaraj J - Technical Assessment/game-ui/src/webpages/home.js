import React from 'react';
import { useNavigate } from "react-router-dom";

const Home = () => {

    const navigate = useNavigate();
    const newGame = () => navigate("/game");
    const resumeGame = () => console.log('Default');

  return(<div className="container">
  <header className="App-header">
  <p className="lead">
        <button className="btn btn-primary btn-lg" id="new-game" onClick={newGame}>New Game</button>
    </p>
    <p className="lead">
        <button className="btn btn-primary btn-lg" id="load-game" onClick={resumeGame}>Load Game</button>
    </p>
  </header>
  
</div>);
}
export default Home;