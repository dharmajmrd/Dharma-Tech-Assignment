import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Routes,
  Link
} from "react-router-dom";
import Home from './home';
import Game from './game';
import Play from './play';
const Webpages = () => {
    return(
        <Router>
            <Routes>
                <Route path="/" element={<Home/>}></Route>
                <Route path = "/game" element = {<Game/>} />
                <Route path = "/play" element = {<Play/>} />                
            </Routes>
        </Router>
    );
};
export default Webpages;