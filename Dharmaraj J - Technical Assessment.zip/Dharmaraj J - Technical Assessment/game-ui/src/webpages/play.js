import React, { useState, useEffect } from 'react';
import { PUT, JSON_CONTENT_TYPE, BASE_URL } from "../utils/constants.js";
import Modal1 from "./modal";
import {useLocation} from 'react-router-dom';

const Play = ({route,navigate}) =>{

    const location = useLocation();

    console.log(location);

    const [playerInfo, setPlayerInfo] = useState([]);
    const [pitList1, setPitList1] = useState([]);
    const [pitList2, setPitList2] = useState([]);
    

    const [modal, setModal] = useState(false);
    const [title, setTitle] = useState("Alert");
    const [content, setContent] = useState("");
    const Toggle = () => setModal(!modal);


    const url = `${BASE_URL}/play/${location.state.uuid}`;

     useEffect(() => {
        fetch(url)
           .then((response) => response.json())
           .then((data) => {
              console.log(data);
              preparePits(data);
           })
           .catch((err) => {
              console.log(err);
           });
     }, []);


     const Pick = (e) => {
        const pitIndex = e.target.id.replace(/^\D+/g, "");
     const moveUrl = `${BASE_URL}/move`;
     const currentPlayerName = document.getElementById("player-turn").innerText;
     const moveRequest = {
         uuid: location.state.uuid,
         player_type: currentPlayerName,
         index: pitIndex
       };

     //useEffect(() => {
        fetch(moveUrl, {
            headers: {
                  "Content-Type": JSON_CONTENT_TYPE
                },
                method: PUT,
                body: JSON.stringify(moveRequest)
         }).then((response) => response.json())
         .then((response) => {
            console.log(response);
            if(response.errorCode != null){
                Toggle();
                setContent(response.errorMessage)
            }else{
                preparePits(response);
                if (response.status == "END") {
                    setContent("Winner is "+response.winnerPlayer);
                }
            }
         }).catch((err) => {
            console.log(err);
         });
     //});
    
     }

     const getPlayerTypeByName = playerName => {
        const firstPlayer = document.getElementById("player1-name").innerText;
        return playerName === firstPlayer ? "FIRST" : "SECOND";
      };

      const preparePits = data => {

            setPlayerInfo(data)
            const arr1 = [];
            const arr2 = [];

            if(data.board){
            for (let index = 0; index <= 5; index++) {
                arr1.push(<td key={'pit-p1'+index}>
                        <button className="pit" key={"pit-b1"+index} id={"pit"+index} onClick={Pick}>{data.board[index]}</button>
                      </td>);
            }

            for (let index = 13; index >= 6; index--) {
                if(index == 6 || index == 13){
                    arr2.push(<td className="large-pit" key={"pit-lp2"+index} id={"pit"+index} rowSpan="3">{data.board[index]}</td>);
                }
                else{
                    arr2.push(<td key={"pit-p2"+index}>
                        <button className="pit" key={"pit-b2"+index} id={"pit"+index} onClick={Pick}>{data.board[index]}</button>
                      </td>);
                }
            }
        }

              setPitList1(arr1);
              setPitList2(arr2);

      }
  
     return (<div>
       <Modal1 show={modal} close={Toggle} title={title}>
        {content}
      </Modal1>
    <div id="modal" />
     <div>
        <header>
      <h1 className="header-mancala display-4">Mancala</h1>
      <div className="status">
        <div className="status-row">
          <label htmlFor="game-id">Game ID: </label>
          <span id="game-id">
            <span>{playerInfo.uuid}</span>
          </span>
        </div>
        <div className="status-row">
          <label>Status: </label>
          <span id="game-status">
            <span>{playerInfo.status}</span>
          </span>
        </div>
        <div className="status-row">
          <label htmlFor="total-turn">Total Turns: </label>
          <span id="total-turn">{playerInfo.totalTurn}</span>
        </div>
        <div className="status-row">
          <label htmlFor="player-turn" className="status-label">Current Turn: </label>
          <span id="player-turn"><span/>{playerInfo.playerTurn}</span>
        </div>
      </div>
    </header>
     </div>
     <div className="board-container">
     <table className="board">
       <tbody>
         <tr className="player-row" id="player2-row">
           <td key="p2-name" colSpan="8"><h3 className="player-name"><span id="player2-name">{playerInfo.secondPlayer?.name}</span></h3></td>
         </tr>
         <tr className="board-row">
           {pitList2}
         </tr>
         <tr className="blank-row">
           <td key="blank-name" id="blank-row" colSpan="6">Mancala</td>
         </tr>
         <tr className="board-row">
           {pitList1}
         </tr>
         <tr className="player-row" id="player1-row">
           <td key="p1-name" colSpan="8"><h3 className="player-name"><span id="player1-name">{playerInfo.firstPlayer?.name}</span></h3></td>
         </tr>
       </tbody>
     </table>
   </div>
   </div>)

}

export default Play;