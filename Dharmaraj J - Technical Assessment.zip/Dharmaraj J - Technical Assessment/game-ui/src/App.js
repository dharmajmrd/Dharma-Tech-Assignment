import logo from './logo.svg';
import './App.css';
import Webpages from './webpages';

const App = () => {
  return (<div>
    <Webpages />
  </div>);
}

export default App;
