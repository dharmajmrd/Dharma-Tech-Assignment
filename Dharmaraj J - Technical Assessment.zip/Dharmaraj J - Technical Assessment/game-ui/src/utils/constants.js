export const JSON_CONTENT_TYPE = "application/json;charset=utf-8";
export const POST = "POST";
export const PUT = "PUT";
export const BASE_URL = "http://localhost:8080/game";