package com.bol.online.game.core.mappers;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.dto.response.GameResponseDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.UUID;

@Mapper(componentModel = "spring")
public interface GameMapper {

    PlayerMapper playerMapper = Mappers.getMapper(PlayerMapper.class);

    GameResponseDto gameResponseFromGameEntity(GameEntity gameEntity);

    GameRequestDto responseDtoToRequestDto(GameResponseDto responseDto);

    GameEntity requestDtoToEntity(GameRequestDto requestDto);

    default GameEntity prepareGameEntity(GameStartRequest gameStartRequest, int[] board){

        return GameEntity
                .builder()
                .uuid(UUID.randomUUID())
                .firstPlayer(playerMapper.requestDtoToEntity(gameStartRequest.getFirstPlayer()))
                .secondPlayer(playerMapper.requestDtoToEntity(gameStartRequest.getSecondPlayer()))
                .status(GameStatus.START)
                .playerTurn(PlayerType.FIRST)
                .board(board)
                .build();
    }
}
