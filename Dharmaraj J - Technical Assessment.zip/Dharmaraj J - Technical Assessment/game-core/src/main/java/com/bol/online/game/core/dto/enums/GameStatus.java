package com.bol.online.game.core.dto.enums;

public enum GameStatus {
    START, PROGRESS, END
}
