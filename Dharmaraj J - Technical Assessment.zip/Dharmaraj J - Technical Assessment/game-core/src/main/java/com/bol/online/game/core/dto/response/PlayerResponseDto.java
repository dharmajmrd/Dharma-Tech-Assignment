package com.bol.online.game.core.dto.response;

import com.bol.online.game.core.dto.base.Base;
import com.bol.online.game.core.dto.enums.PlayerType;
import lombok.*;

import java.util.UUID;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PlayerResponseDto extends Base {
    private UUID uuid;
    private String name;
    private PlayerType playerType;
}
