package com.bol.online.game.core.mappers;


import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.response.GameStartResponse;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface GameStartResponseMapper {
    GameStartResponse gameStartResponseFromGameEntity(GameEntity gameEntity);
}
