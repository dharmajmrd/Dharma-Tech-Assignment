package com.bol.online.game.core.dto.request;

import com.bol.online.game.core.dto.base.Base;
import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import lombok.*;

import java.util.UUID;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GameRequestDto extends Base {
    private UUID uuid;
    private GameStatus status;
    private int[] board;
    private PlayerType playerTurn;
    private int totalTurn;
    private PlayerRequestDto firstPlayer;
    private PlayerRequestDto secondPlayer;
    private String winnerPlayer;
}
