package com.bol.online.game.core.dto.request;

import com.bol.online.game.core.dto.base.Base;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.UUID;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PlayerRequestDto extends Base {
    @NotNull(message = "Player uuid required")
    private UUID uuid;
    @NotNull(message = "Player name required")
    private String name;
    @NotNull(message = "Player type required")
    @JsonProperty(value = "player_type")
    private PlayerType playerType;
}
