package com.bol.online.game.core.dto.exceptions;

public class InvalidGameStateException extends RuntimeException {

  public InvalidGameStateException() {}
  public InvalidGameStateException(String message) {
    super(message);
  }
}