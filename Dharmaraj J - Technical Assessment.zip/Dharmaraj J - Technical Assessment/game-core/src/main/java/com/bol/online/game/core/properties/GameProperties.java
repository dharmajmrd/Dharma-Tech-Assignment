package com.bol.online.game.core.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class GameProperties {

    @Value("${game.total.pits}")
    private Integer totalPits;

    @Value("${game.player1.large.pit.index}")
    private Integer firstPlayerLargePitIndex;

    @Value("${game.player2.large.pit.index}")
    private Integer secondPlayerLargePitIndex;

    @Value("${game.total.pits.per.row}")
    private Integer totalPitsPerRow;

    @Value("${game.pits.max.stone}")
    private Integer maxStonesPerPit;


}
