package com.bol.online.game.core.mappers;


import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.response.PlayerResponseDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PlayerResponseMapper {
    PlayerResponseDto entityToDto(PlayerEntity playerEntity);
}
