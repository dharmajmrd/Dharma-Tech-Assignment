package com.bol.online.game.core.dto.exceptions;

public class GameNotFoundException extends RuntimeException {
    public GameNotFoundException() {}
    public GameNotFoundException(String message) {
        super(message);
    }
}
