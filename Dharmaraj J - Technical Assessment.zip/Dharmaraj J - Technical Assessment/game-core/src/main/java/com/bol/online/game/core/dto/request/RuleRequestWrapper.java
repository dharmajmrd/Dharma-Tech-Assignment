package com.bol.online.game.core.dto.request;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RuleRequestWrapper {

    GameMoveRequest gameMoveRequest;
    GameRequestDto gameRequestDto;

}
