package com.bol.online.game.core.dto.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MancalaException extends RuntimeException{

    String errorCode;
    String errorMessage;

    public MancalaException(String errorCode,String errorMessage){
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
}
