package com.bol.online.game.core.dto.entities;


import com.bol.online.game.core.dto.base.Base;
import com.bol.online.game.core.dto.enums.PlayerType;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.UUID;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Document("Player")
public class PlayerEntity extends Base {
    @Id
    private UUID uuid;
    private String name;
    private PlayerType playerType;
}
