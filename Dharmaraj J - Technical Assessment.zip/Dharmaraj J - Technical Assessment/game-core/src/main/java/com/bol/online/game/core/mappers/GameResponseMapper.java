package com.bol.online.game.core.mappers;


import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.response.GameResponseDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface GameResponseMapper {
    GameResponseDto dtoToResponse(GameRequestDto gameRequestDto);
}
