package com.bol.online.game.core.dto.request;


import com.bol.online.game.core.dto.base.Base;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GamePlayRequest extends Base {
    @NotNull(message = "Game id required")
    private String uuid;
}
