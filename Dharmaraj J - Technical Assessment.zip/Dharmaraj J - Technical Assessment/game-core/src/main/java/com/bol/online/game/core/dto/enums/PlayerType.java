package com.bol.online.game.core.dto.enums;

public enum PlayerType {
    FIRST(6), SECOND(13);

    private final Integer largePitIndex;

    PlayerType(Integer largePitIndex){
        this.largePitIndex = largePitIndex;
    }

    public Integer getLargePitIndex(){
        return this.largePitIndex;
    }
}
