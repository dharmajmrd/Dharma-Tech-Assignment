package com.bol.online.game.core.dto.entities;

import com.bol.online.game.core.dto.base.Base;
import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.UUID;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Document("Game")
public class GameEntity extends Base {
    @Id
    private UUID uuid;
    private GameStatus status;
    private int[] board;
    private int totalTurn;
    private PlayerType playerTurn;
    private PlayerEntity firstPlayer;
    private PlayerEntity secondPlayer;
    private String winnerPlayer;

    //JPA Optimistic Lock to avoid playing same game in parallel
    //@Version Long version;
}
