package com.bol.online.game.core.dto.exceptions;

public class InvalidMoveException extends RuntimeException {

  public InvalidMoveException() {}
  public InvalidMoveException(String message) {
    super(message);
  }
}
