package com.bol.online.game.core.utils;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.PlayerRequestDto;
import com.bol.online.game.core.properties.GameProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.stream.IntStream;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class GameHelper {

    @Autowired
    GameProperties gameProperties;

    private static final Logger logger = LoggerFactory.getLogger(GameHelper.class);

    public int[] getInitialBoard() {
        logger.info("Initializing board for game");
        int[] board = new int[this.gameProperties.getTotalPits()];
        IntStream.range(0, this.gameProperties.getTotalPits())
                .filter(index -> (index != this.gameProperties.getFirstPlayerLargePitIndex() && index != this.gameProperties.getSecondPlayerLargePitIndex()))
                .forEach(index -> board[index] = this.gameProperties.getMaxStonesPerPit());
        return board;
    }

    public int getLargePitByPlayerType(PlayerType playerType) {
        logger.debug("Player score pit for player type {}", playerType);
        return switch (playerType) {
            case FIRST -> Constants.FIRST_PLAYER_SCORE_PIT;
            case SECOND -> Constants.SECOND_PLAYER_SCORE_PIT;
        };
    }

    public int maxIndexByPlayerType(PlayerType type) {
        return this.gameProperties.getTotalPitsPerRow() + (type.ordinal() * this.gameProperties.getTotalPitsPerRow()) - 2;
    }

    public int minIndexByPlayerType(PlayerType type) {
        return type.ordinal() * this.gameProperties.getTotalPitsPerRow();
    }

    public int getOpponentPitIndex(int currentIndex) {
        return this.gameProperties.getTotalPits() - currentIndex - 2;
    }

    public int captureOpponentStones(int nextIndex, int[] board) {
        int oppositeIndex = getOpponentPitIndex(nextIndex);
        int scoreToAd = ++board[oppositeIndex];
        board[nextIndex] = 0;
        board[oppositeIndex] = 0;
        return scoreToAd;
    }

    public PlayerType getOpponentByType(PlayerType currentPlayer) {
        logger.debug("Request opponent against player type {}", currentPlayer);
        return switch (currentPlayer) {
            case FIRST -> PlayerType.SECOND;
            case SECOND -> PlayerType.FIRST;
        };
    }

    public PlayerRequestDto getPlayerFromGameEntityByType(GameRequestDto gameRequestDto, PlayerType playerType) {
        logger.debug("Request opponent against player type {} from game entity", playerType);
        return switch (playerType) {
            case FIRST -> gameRequestDto.getFirstPlayer();
            case SECOND -> gameRequestDto.getSecondPlayer();
        };
    }

    public int collectStones(PlayerType playerType, int[] board) {
        logger.debug("Collect stones against player type : {}", playerType);
        return IntStream
                .rangeClosed(minIndexByPlayerType(playerType), maxIndexByPlayerType(playerType))
                .map(i -> board[i]).sum();
    }

    public void fillBoard(PlayerType playerType, int[] board, int number) {
        logger.debug("Fill board for player type {} with value {}", playerType, number);
        IntStream.rangeClosed(minIndexByPlayerType(playerType), maxIndexByPlayerType(playerType))
                .forEach(i -> board[i] = number);
    }

    public boolean anyEmptyBoard(int[] board) {
        return checkPlayerBoardEmptyByType(PlayerType.FIRST, board) || checkPlayerBoardEmptyByType(PlayerType.SECOND, board);
    }

    private boolean checkPlayerBoardEmptyByType(PlayerType playerType, int[] board) {
        logger.debug("Check board empty against player type {}", playerType);
        return IntStream
                .rangeClosed(minIndexByPlayerType(playerType), maxIndexByPlayerType(playerType))
                .noneMatch(index -> board[index] != 0);
    }

}
