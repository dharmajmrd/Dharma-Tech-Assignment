package com.bol.online.game.core.dto.request;

import com.bol.online.game.core.dto.base.Base;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.*;


@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GameMoveRequest extends Base {
    @NotNull(message = "Game id required")
    @JsonProperty(value = "uuid")
    private String uuid;
    @JsonProperty(value = "player_type")
    @NotNull(message = "Player type required")
    private PlayerType playerTurn;
    private int index;
    private int currentStones;
    private boolean isPlayerBoard = Boolean.TRUE;
    private boolean isFinalOnLargePit;
}
