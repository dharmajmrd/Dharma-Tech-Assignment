package com.bol.online.game.core.utils;

public class Constants {

    public static final String RULE_ENGINE_BASE_URL = "/rule";
    public static final String RULE_VALIDATE_MOVE = "/validate";

    //Player Service EndPoints
    public static final String PLAYER_SERVICE_BASE_URL = "/player";
    public static final String PLAYER_CREATE_URL = "/create";

    //Game Service EndPoints

    public static final String GAME_BASE_URL = "/game";
    public static final String GAME_START_URL = "/start";
    public static final String GAME_MOVE_URL = "/move";
    public static final String GAME_PLAY_URL = "/play";

    public static final String GAME_GET_URL = "/get";

    public static final String GAME_DELETE_URL = "/delete";

    public static final String UUID_PATH = "/{uuid}";


    public static int FIRST_PLAYER_SCORE_PIT = 6;
    public static int SECOND_PLAYER_SCORE_PIT = 13;


    private Constants() {

    }
}
