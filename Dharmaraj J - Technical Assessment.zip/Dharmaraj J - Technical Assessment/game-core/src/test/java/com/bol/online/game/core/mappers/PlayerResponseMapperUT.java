package com.bol.online.game.core.mappers;

import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.response.PlayerResponse;
import com.bol.online.game.core.dto.response.PlayerResponseDto;
import com.bol.online.game.core.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayerResponseMapperUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private PlayerResponseMapper mapper;

    @Spy
    private PlayerResponseMapper mapper1 = Mappers.getMapper(PlayerResponseMapper.class);

    @Test
    public void testPlayerResponseFromPlayerEntity() {
        when(mapper.entityToDto(any(PlayerEntity.class)))
                .thenReturn(dataHelper.firstPlayerResponse());

        PlayerResponseDto playerResponse = mapper.entityToDto(dataHelper.firstPlayerEntity());

        Assertions.assertEquals(dataHelper.firstPlayerResponse(), playerResponse);
        verify(mapper, times(1))
                .entityToDto(dataHelper.firstPlayerEntity());
    }

    @Test
    public void testPlayerResponseFromPlayerEntity1() {
        PlayerResponseDto response = mapper1.entityToDto(dataHelper.firstPlayerEntity());
        Assertions.assertEquals(dataHelper.firstPlayerResponse(), response);
    }

}
