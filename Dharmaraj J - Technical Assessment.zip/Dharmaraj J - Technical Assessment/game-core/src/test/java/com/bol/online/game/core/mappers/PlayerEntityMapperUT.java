package com.bol.online.game.core.mappers;

import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.response.PlayerResponse;
import com.bol.online.game.core.dto.response.PlayerResponseDto;
import com.bol.online.game.core.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayerEntityMapperUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private PlayerMapper mapper;

    @Spy
    private PlayerMapper mapper1 = Mappers.getMapper(PlayerMapper.class);

    @Test
    public void testPlayerEntityFromPlayerResponse() {
        when(mapper.playerEntityFromPlayerResponse(any(PlayerResponseDto.class)))
                .thenReturn(dataHelper.firstPlayerEntity());

        PlayerEntity playerEntity = mapper.playerEntityFromPlayerResponse(dataHelper.firstPlayerResponse());

        Assertions.assertEquals(dataHelper.firstPlayerEntity(), playerEntity);
        verify(mapper, times(1))
                .playerEntityFromPlayerResponse(dataHelper.firstPlayerResponse());
    }

    @Test
    public void testPlayerEntityFromPlayerResponse1() {
        PlayerEntity firstPlayer = mapper1.playerEntityFromPlayerResponse(dataHelper.firstPlayerResponse());
        Assertions.assertEquals(dataHelper.firstPlayerEntity(), firstPlayer);
    }
}
