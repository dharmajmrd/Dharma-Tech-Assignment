package com.bol.online.game.core.mappers;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GameResponseMapperUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private GameMapper mapper;

    @Spy
    private final GameMapper gameResponseMapper = Mappers.getMapper(GameMapper.class);


    @Test
    public void testGameResponseFromGameEntity() {
        when(mapper.gameResponseFromGameEntity(any(GameEntity.class)))
        .thenReturn(dataHelper.gameResponse());

        GameResponseDto gameResponse = mapper.gameResponseFromGameEntity(dataHelper.gameEntity());

        Assertions.assertEquals(dataHelper.gameResponse(), gameResponse);
        verify(mapper, times(1))
                .gameResponseFromGameEntity(dataHelper.gameEntity());
    }

    @Test
    public void testGameResponseFromGameEntity1() {
        GameResponseDto gameResponse = gameResponseMapper.gameResponseFromGameEntity(dataHelper.gameEntity());
        Assertions.assertEquals(dataHelper.gameResponse(), gameResponse);
    }
}
