package com.bol.online.game.core.mappers;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.response.GameStartResponse;
import com.bol.online.game.core.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GameStartResponseMapperUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private GameStartResponseMapper mapper;

    @Spy
    private GameStartResponseMapper mapper1 = Mappers.getMapper(GameStartResponseMapper.class);

    @Test
    public void testGameStartResponseFromGameEntity() {
        when(mapper.gameStartResponseFromGameEntity(any(GameEntity.class)))
                .thenReturn(dataHelper.gameStartResponse());

        GameStartResponse gameStartResponse = mapper.gameStartResponseFromGameEntity(dataHelper.gameEntity());

        Assertions.assertEquals(dataHelper.gameStartResponse(), gameStartResponse);
        verify(mapper, times(1))
                .gameStartResponseFromGameEntity(dataHelper.gameEntity());
    }

    @Test
    public void testGameStartResponseFromGameEntity1() {
        GameStartResponse gameStartResponse = mapper1.gameStartResponseFromGameEntity(dataHelper.gameEntity());
        Assertions.assertEquals(dataHelper.gameStartResponse(), gameStartResponse);
    }
}
