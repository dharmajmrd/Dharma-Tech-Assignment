package com.bol.online.game.services.rules.types;

import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.services.rules.GameRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.BootstrapRegistry;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
/**
 * New instance per request/thread to avoid overlap on applying rules
 */
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class LargePitRule extends GameRules {

    private static final Logger logger = LoggerFactory.getLogger(GameRules.class);

    @Override
    public void apply(GameMoveRequest moveRequest, GameRequestDto gameRequestDto) {
        int largerPitIndex = gameHelper.getLargePitByPlayerType(moveRequest.getPlayerTurn());
        if (moveRequest.getIndex() == largerPitIndex) {
            logger.info("Evaluating large pit rule..");
            ++gameRequestDto.getBoard()[largerPitIndex];
            moveRequest.setCurrentStones(moveRequest.getCurrentStones() - 1);
            logger.info("Final move exists on larger pit");
            moveRequest.setFinalOnLargePit(moveRequest.getCurrentStones() == 0);

            moveRequest.setPlayerBoard(!moveRequest.isPlayerBoard());
        }

    }
}
