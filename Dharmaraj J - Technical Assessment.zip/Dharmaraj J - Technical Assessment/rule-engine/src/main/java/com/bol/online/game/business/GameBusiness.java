package com.bol.online.game.business;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.RuleRequestWrapper;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.mappers.GameResponseMapper;
import com.bol.online.game.services.RuleEngineService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GameBusiness {

    private static final Logger logger = LoggerFactory.getLogger(GameBusiness.class);

    @Autowired
    private RuleEngineService ruleEngineService;

    @Autowired
    private GameResponseMapper gameResponseMapper;


    public GameResponseDto validateMove(RuleRequestWrapper ruleRequestWrapper) {
        logger.debug("GameStartRequest {} received in business for start", ruleRequestWrapper);
        if(ruleEngineService.isMoveValid(ruleRequestWrapper.getGameMoveRequest(), ruleRequestWrapper.getGameRequestDto().getBoard())){
            return calculateScore(ruleRequestWrapper.getGameMoveRequest(),ruleRequestWrapper.getGameRequestDto());
        }
        return null;
    }

    public GameResponseDto calculateScore(GameMoveRequest request, GameRequestDto gameRequestDto) {
        logger.debug("GameStartRequest {} received in business for start", request);
        return gameResponseMapper.dtoToResponse(ruleEngineService
                .calculateScore(gameRequestDto,request));
    }

}
