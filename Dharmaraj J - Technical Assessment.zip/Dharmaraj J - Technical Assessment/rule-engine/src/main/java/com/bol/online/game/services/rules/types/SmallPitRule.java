package com.bol.online.game.services.rules.types;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.services.rules.GameRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
/**
 * New instance per request/thread to avoid overlap on applying rules
 */
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SmallPitRule extends GameRules {

    private static final Logger logger = LoggerFactory.getLogger(SmallPitRule.class);

    @Override
    public void apply(GameMoveRequest moveRequest, GameRequestDto gameRequestDto) {
        if (moveRequest.getIndex() != this.gameProperties.getFirstPlayerLargePitIndex() &&
                moveRequest.getIndex() != this.gameProperties.getSecondPlayerLargePitIndex()) { //If the current pit index not of large pit
            logger.info("Applying small pit rule..");
            if (canCollectOpponentStones(moveRequest, gameRequestDto)) {
                logger.info("Capturing opponent stones...");
                int largerPitIndex = gameHelper.getLargePitByPlayerType(moveRequest.getPlayerTurn());
                gameRequestDto.getBoard()[largerPitIndex] += gameHelper.captureOpponentStones(moveRequest.getIndex(), gameRequestDto.getBoard());
            } else {
                logger.info("Adding stones to next pits");
                ++gameRequestDto.getBoard()[moveRequest.getIndex()];
            }
            moveRequest.setCurrentStones(moveRequest.getCurrentStones() - 1);
        }
    }

    private boolean canCollectOpponentStones(GameMoveRequest moveRequest, GameRequestDto gameRequestDto) {
        return moveRequest.isPlayerBoard() &&
                moveRequest.getCurrentStones() == 1 &&
                gameRequestDto.getBoard()[moveRequest.getIndex()] == 0 &&
                gameRequestDto.getBoard()[gameHelper.getOpponentPitIndex(moveRequest.getIndex())] != 0;
    }
}
