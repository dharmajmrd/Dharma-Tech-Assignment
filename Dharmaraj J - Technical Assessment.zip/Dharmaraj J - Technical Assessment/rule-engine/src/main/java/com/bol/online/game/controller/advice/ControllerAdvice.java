package com.bol.online.game.controller.advice;

import com.bol.online.game.core.dto.exceptions.GameNotFoundException;
import com.bol.online.game.core.dto.exceptions.InvalidGameStateException;
import com.bol.online.game.core.dto.exceptions.InvalidMoveException;
import com.bol.online.game.core.dto.response.ResponseError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.Optional;

@RestControllerAdvice
public class ControllerAdvice {

    private static final Logger logger = LoggerFactory.getLogger(ControllerAdvice.class);

    @ExceptionHandler(value
            = IllegalArgumentException.class)
    public ResponseEntity<ResponseError> handleIllegalArgumentException(
            IllegalArgumentException e) {
        String error = Optional.ofNullable(e.getMessage()).orElse(e.getClass().getName())
                + " [Internal server exception! => (IllegalArgumentException)]";
        ResponseError errorResponse = ResponseError.builder()
                .createdAt(LocalDateTime.now().toString())
                .detailedMessage(error)
                .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .exceptionName(IllegalArgumentException.class.getName())
                .errorMessage(e.getMessage()).build();
        logger.error("Response error created : {}", errorResponse);
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(value
            = InvalidMoveException.class)
    public ResponseEntity<ResponseError> handleInvalidMoveException(
            InvalidMoveException e) {
        String error = Optional.ofNullable(e.getMessage()).orElse(e.getClass().getName())
                + " [Internal server exception! => (InvalidMoveException)]";
        ResponseError errorResponse = ResponseError.builder()
                .createdAt(LocalDateTime.now().toString())
                .detailedMessage(error)
                .errorCode(HttpStatus.NOT_ACCEPTABLE.value())
                .exceptionName(InvalidMoveException.class.getName())
                .errorMessage(e.getMessage()).build();
        logger.error("Response error created : {}", errorResponse);
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_ACCEPTABLE);
    }

}
