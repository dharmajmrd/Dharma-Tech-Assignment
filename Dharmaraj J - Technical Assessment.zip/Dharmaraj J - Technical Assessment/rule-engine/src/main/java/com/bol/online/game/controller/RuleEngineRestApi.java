package com.bol.online.game.controller;


import com.bol.online.game.business.GameBusiness;
import com.bol.online.game.core.dto.request.RuleRequestWrapper;
import com.bol.online.game.core.dto.response.GameResponseDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.bol.online.game.core.utils.Constants.*;
@RestController
@RequestMapping(RULE_ENGINE_BASE_URL)
public class RuleEngineRestApi {

    private static final Logger logger = LoggerFactory.getLogger(RuleEngineRestApi.class);

    @Autowired
    private GameBusiness business;

    @PostMapping(RULE_VALIDATE_MOVE)
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "API To Validate Move",
            description = "This Api validates the move initiated by the player if it is within his boundary")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Validation success and move is valid")
    })
    public ResponseEntity<GameResponseDto> validate(@Valid @RequestBody RuleRequestWrapper ruleRequestWrapper) {
        logger.debug("GamePlayRequest received : {}", ruleRequestWrapper);
        return ResponseEntity.ok(business.validateMove(ruleRequestWrapper));
    }

}
