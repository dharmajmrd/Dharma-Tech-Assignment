package com.bol.online.game.services.Impl;

import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.exceptions.InvalidMoveException;
import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.properties.GameProperties;
import com.bol.online.game.core.utils.GameHelper;
import com.bol.online.game.services.RuleEngineService;
import com.bol.online.game.services.rules.GameRules;
import org.apache.commons.lang3.Range;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class RuleEngineServiceImpl implements RuleEngineService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RuleEngineServiceImpl.class);

    @Autowired
    GameHelper gameHelper;

    @Autowired
    GameProperties gameProperties;

    @Autowired
    List<GameRules> gameRules;

    @Override
    public boolean isMoveValid(GameMoveRequest moveRequest, int[] board) {

        LOGGER.debug("Game {} received for validateMove", moveRequest.getUuid());

        Range<Integer>  range = Range.between(gameHelper.maxIndexByPlayerType(moveRequest.getPlayerTurn()), gameHelper.minIndexByPlayerType(moveRequest.getPlayerTurn()));
        if (!range.contains(moveRequest.getIndex()) || board[moveRequest.getIndex()] == 0) {
            LOGGER.error("Index {} is not a valid move.", moveRequest.getIndex());
            throw new InvalidMoveException(String.format("Index %d is not a valid move.", moveRequest.getIndex()));
        }
        return Boolean.TRUE;
    }

    @Override
    public GameRequestDto calculateScore(GameRequestDto gameRequestDto, GameMoveRequest moveRequest) {

        if(LOGGER.isDebugEnabled())
        LOGGER.debug("Game id {} received for evaluating score", moveRequest.getUuid());

        moveRequest.setCurrentStones(gameRequestDto.getBoard()[moveRequest.getIndex()]);

        gameRequestDto.getBoard()[moveRequest.getIndex()] = 0;
        sow(gameRequestDto, moveRequest);
        gameRequestDto.setTotalTurn(gameRequestDto.getTotalTurn() + 1);
        if (!moveRequest.isFinalOnLargePit()) {
            gameRequestDto.setPlayerTurn(gameHelper.getOpponentByType(moveRequest.getPlayerTurn()));
        }
        evaluateEnd(gameRequestDto);

        return gameRequestDto;
    }

    private void sow(GameRequestDto gameRequestDto, GameMoveRequest moveRequest) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Current pit stones : {}", moveRequest.getCurrentStones());
            LOGGER.debug("Applied Rules are : {}",gameRules);
        }
        while (moveRequest.getCurrentStones() > 0) {
            moveRequest.setIndex(moveRequest.getIndex() + 1);

            gameRules.forEach(rule ->
                    rule.apply(moveRequest, gameRequestDto));
        }
    }

    private void evaluateEnd(GameRequestDto gameRequestDto) {
        LOGGER.debug("Game {} received for evaluating end game", gameRequestDto.getUuid());
        if (gameHelper.anyEmptyBoard(gameRequestDto.getBoard())) {
            gameRequestDto.getBoard()[this.gameProperties.getFirstPlayerLargePitIndex()] += gameHelper.collectStones(PlayerType.FIRST, gameRequestDto.getBoard());
            gameRequestDto.getBoard()[this.gameProperties.getSecondPlayerLargePitIndex()] += gameHelper.collectStones(PlayerType.SECOND, gameRequestDto.getBoard());
            gameRequestDto.setWinnerPlayer(gameRequestDto.getBoard()[this.gameProperties.getFirstPlayerLargePitIndex()] > gameRequestDto.getBoard()[this.gameProperties.getSecondPlayerLargePitIndex()] ?
                    gameHelper.getPlayerFromGameEntityByType(gameRequestDto, PlayerType.FIRST).getName() : gameHelper.getPlayerFromGameEntityByType(gameRequestDto, PlayerType.SECOND).getName());
            fillBoard(gameRequestDto.getBoard());
            gameRequestDto.setStatus(GameStatus.END);
            LOGGER.info("Game {} successfully finished.", gameRequestDto.getUuid());
        }
    }

    private void fillBoard(int[] board) {
        for (PlayerType playerType : Arrays.asList(PlayerType.FIRST, PlayerType.SECOND)) {
            gameHelper.fillBoard(playerType, board, 0);
        }
    }
}
