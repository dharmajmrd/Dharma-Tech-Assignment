package com.bol.online.game.services.rules;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.properties.GameProperties;
import com.bol.online.game.core.utils.GameHelper;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class GameRules {

    @Autowired
    protected GameHelper gameHelper;

    @Autowired
    protected GameProperties gameProperties;

    public abstract void apply(GameMoveRequest moveRequest, GameRequestDto gameRequestDto);

    public GameProperties getGameProperties() {
        return gameProperties;
    }
}
