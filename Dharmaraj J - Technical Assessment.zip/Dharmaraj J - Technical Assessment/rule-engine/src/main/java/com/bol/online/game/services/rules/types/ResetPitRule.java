package com.bol.online.game.services.rules.types;

import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.services.rules.GameRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
/**
 * New instance per request/thread to avoid overlap on applying rules
 */
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ResetPitRule extends GameRules {

    private static final Logger logger = LoggerFactory.getLogger(ResetPitRule.class);

    @Override
    public void apply(GameMoveRequest moveRequest, GameRequestDto gameRequestDto) {
        logger.info("Resetting index as index exceed from limit {}", this.gameProperties.getTotalPits());
        if(moveRequest.getIndex() >= this.gameProperties.getTotalPits() ) {
            logger.info("Resetting index as index exceed from limit {}", this.gameProperties.getTotalPits());
            moveRequest.setIndex(0);
        }
    }
}
