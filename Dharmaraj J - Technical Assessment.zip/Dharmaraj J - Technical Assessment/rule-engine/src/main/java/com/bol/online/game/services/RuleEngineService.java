package com.bol.online.game.services;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.services.rules.GameRules;
import com.bol.online.game.services.rules.types.LargePitRule;
import com.bol.online.game.services.rules.types.ResetPitRule;
import com.bol.online.game.services.rules.types.SmallPitRule;

public interface RuleEngineService {
    GameRules[] MANCALA_RULES = { new ResetPitRule(), new SmallPitRule(), new LargePitRule() };
    boolean isMoveValid(GameMoveRequest request, int[] board);
    GameRequestDto calculateScore(GameRequestDto gameRequestDto, GameMoveRequest moveRequest);
}
