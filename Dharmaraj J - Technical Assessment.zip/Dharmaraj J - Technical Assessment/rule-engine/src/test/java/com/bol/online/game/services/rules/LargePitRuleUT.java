package com.bol.online.game.services.rules;

import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.services.rules.types.LargePitRule;
import com.bol.online.game.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class LargePitRuleUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private LargePitRule largePitRule;

    @Test
    public void testEvaluate() {
        doNothing().when(largePitRule)
                .apply(any(GameMoveRequest.class), any(GameRequestDto.class));

        largePitRule.apply(dataHelper.gameMoveRequest(), dataHelper.gameRequestDto());

        verify(largePitRule, times(1))
                .apply(dataHelper.gameMoveRequest(), dataHelper.gameRequestDto());
    }

    @Test
    public void testEvaluate1() {
        GameMoveRequest moveRequest = dataHelper.gameMoveRequest();
        GameRequestDto gameRequestDto = dataHelper.gameRequestDtoForIT();

        largePitRule.apply(moveRequest, gameRequestDto);

        Assertions.assertEquals(5, moveRequest.getCurrentStones());
        Assertions.assertEquals(3, moveRequest.getIndex());
        Assertions.assertFalse(moveRequest.isFinalOnLargePit());
        Assertions.assertTrue(moveRequest.isPlayerBoard());
        Assertions.assertEquals(PlayerType.FIRST, moveRequest.getPlayerTurn());
    }
}
