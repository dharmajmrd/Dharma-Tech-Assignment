package com.bol.online.game.services.rules;

import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.properties.GameProperties;
import com.bol.online.game.services.rules.types.SmallPitRule;
import com.bol.online.game.utils.DataHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SmallPitRuleUT {

    private final DataHelper dataHelper = new DataHelper();

    @InjectMocks
    private SmallPitRule smallPitRule;

    @Mock
    private GameProperties gameProperties;

    @Mock
    private SmallPitRule smallPitRule1;

    @Test
    public void testEvaluate() {
        doNothing().when(smallPitRule1)
                .apply(any(GameMoveRequest.class), any(GameRequestDto.class));

        smallPitRule1.apply(dataHelper.gameMoveRequest(), dataHelper.gameRequestDto());

        verify(smallPitRule1, times(1))
                .apply(dataHelper.gameMoveRequest(), dataHelper.gameRequestDto());
    }

    @Test
    public void testEvaluate1() {
        GameMoveRequest moveRequest = dataHelper.gameMoveRequest();
        GameRequestDto gameEntity = dataHelper.gameRequestDtoForIT();

        smallPitRule.apply(moveRequest, gameEntity);

        assertEquals(4, moveRequest.getCurrentStones());
        assertEquals(3, moveRequest.getIndex());
        assertFalse(moveRequest.isFinalOnLargePit());
        assertTrue(moveRequest.isPlayerBoard());
        assertArrayEquals(new int[]{6, 6, 6, 7, 6, 6, 0, 6, 6, 6, 6, 6, 6, 0}, gameEntity.getBoard());
        assertEquals(PlayerType.FIRST, gameEntity.getPlayerTurn());
        assertEquals(GameStatus.PROGRESS, gameEntity.getStatus());
    }
}

