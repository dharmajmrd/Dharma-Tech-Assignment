package com.bol.online.game.utils;

import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.PlayerRequestDto;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.dto.response.GameStartResponse;
import com.bol.online.game.core.dto.response.PlayerResponse;
import com.bol.online.game.core.dto.response.PlayerResponseDto;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.MediaType;

import java.util.UUID;


public class DataHelper {

    public static final String GAME_BASE_URL = "/game";
    public static final String GAME_START_URL = GAME_BASE_URL + "/start";
    public static final String GAME_MOVE_URL = GAME_BASE_URL + "/move";
    public static final String GAME_PLAY_URL = GAME_BASE_URL + "/play";
    public static final MediaType MEDIA_TYPE_JSON_UTF8 = new MediaType("application", "json");
    public static final UUID GAME_UUID = UUID.randomUUID();
    public static final UUID FIRST_PLAYER_UUID = UUID.randomUUID();
    public static final UUID SECOND_PLAYER_UUID = UUID.randomUUID();
    public static int[] BOARD = {6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6};
    public static final String FIRST_PLAYER = "FIRST PLAYER";
    public static final String SECOND_PLAYER = "SECOND PLAYER";
    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public int[] getInitBoardForEnd() {
        return new int[]{0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 6, 10};
    }

    public int[] getInitBoard() {
        return new int[]{6, 6, 6, 6, 6, 6, 0, 6, 6, 6, 6, 6, 6, 0};
    }


    public GameRequestDto gameRequestDtoForIT() {
        return GameRequestDto.builder()
                .uuid(UUID.randomUUID())
                .board(getInitBoard())
                .playerTurn(PlayerType.FIRST)
                .status(GameStatus.PROGRESS)
                .firstPlayer(firstPlayerRequestDto())
                .secondPlayer(secondPlayerRequestDto())
                .build();
    }
    public GameMoveRequest gameMoveRequest() {
        return GameMoveRequest.builder()
                .uuid(GAME_UUID.toString())
                .index(3)
                .currentStones(5)
                .isFinalOnLargePit(false)
                .playerTurn(PlayerType.FIRST)
                .isPlayerBoard(Boolean.TRUE)
                .build();
    }

    public GameRequestDto gameRequestDto() {
        return GameRequestDto.builder()
                .uuid(GAME_UUID)
                .board(BOARD)
                .playerTurn(PlayerType.FIRST)
                .status(GameStatus.START)
                .firstPlayer(firstPlayerRequestDto())
                .secondPlayer(secondPlayerRequestDto())
                .winnerPlayer(FIRST_PLAYER)
                .build();
    }

    public PlayerRequestDto firstPlayerRequestDto() {
        return PlayerRequestDto.builder()
                .uuid(FIRST_PLAYER_UUID)
                .playerType(PlayerType.FIRST)
                .name(FIRST_PLAYER)
                .build();
    }

    public PlayerRequestDto secondPlayerRequestDto() {
        return PlayerRequestDto.builder()
                .uuid(SECOND_PLAYER_UUID)
                .playerType(PlayerType.SECOND)
                .name(SECOND_PLAYER)
                .build();
    }

    public GameResponseDto gameResponse() {
        return GameResponseDto.builder()
                .uuid(GAME_UUID)
                .board(BOARD)
                .status(GameStatus.START)
                .playerTurn(PlayerType.FIRST)
                .firstPlayer(firstPlayerResponse())
                .secondPlayer(secondPlayerResponse())
                .winnerPlayer(FIRST_PLAYER)
                .build();
    }

    public PlayerResponseDto firstPlayerResponse() {
        return PlayerResponseDto.builder()
                .uuid(FIRST_PLAYER_UUID)
                .playerType(PlayerType.FIRST)
                .name(FIRST_PLAYER)
                .build();
    }

    public PlayerResponseDto secondPlayerResponse() {
        return PlayerResponseDto.builder()
                .uuid(SECOND_PLAYER_UUID)
                .playerType(PlayerType.SECOND)
                .name(SECOND_PLAYER)
                .build();
    }

    public GameStartResponse gameStartResponse() {
        return GameStartResponse.builder()
                .uuid(GAME_UUID)
                .build();
    }

}

