package com.bol.online.game.services.rules;

import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.properties.GameProperties;
import com.bol.online.game.services.rules.types.ResetPitRule;
import com.bol.online.game.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ResetPitRuleUT {

    private final DataHelper dataHelper = new DataHelper();

    @InjectMocks
    private ResetPitRule resetPitRule;

    @Mock
    private GameProperties gameProperties;

    @Mock
    private ResetPitRule resetPitRule1;

    @Test
    public void testEvaluate() {
        doNothing().when(resetPitRule1)
                .apply(any(GameMoveRequest.class), any(GameRequestDto.class));

        resetPitRule1.apply(dataHelper.gameMoveRequest(), dataHelper.gameRequestDto());

        verify(resetPitRule1, times(1))
                .apply(dataHelper.gameMoveRequest(), dataHelper.gameRequestDto());
    }

    @Test
    public void testEvaluate1() {

        GameProperties gameProperties = new GameProperties();
        gameProperties.setTotalPits(13);
        GameMoveRequest moveRequest = dataHelper.gameMoveRequest();
        moveRequest.setIndex(15);
        resetPitRule.apply(moveRequest, null);

        Assertions.assertEquals(0, moveRequest.getIndex());
    }
}
