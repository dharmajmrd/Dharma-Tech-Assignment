package com.bol.online.game.services;

import com.bol.online.game.core.dto.exceptions.InvalidMoveException;
import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.utils.DataHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RuleEngineServiceImplUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private RuleEngineService service;


    @Test
    public void testValidateMove() {
        when(service.isMoveValid(any(GameMoveRequest.class), any(int[].class))).thenReturn(Boolean.TRUE);

        service.isMoveValid(dataHelper.gameMoveRequest(), DataHelper.BOARD);

        verify(service, times(1))
                .isMoveValid(dataHelper.gameMoveRequest(), DataHelper.BOARD);
    }

    @Test
    public void testValidateMoveInvalidMoveException() {
        doThrow(InvalidMoveException.class).when(service)
                .isMoveValid(any(GameMoveRequest.class), any(int[].class));

        assertThrows(InvalidMoveException.class,
                () -> service.isMoveValid(dataHelper.gameMoveRequest(), DataHelper.BOARD));
    }

    @Test
    public void testEvaluateScore() {
        when(service.calculateScore(any(GameRequestDto.class), any(GameMoveRequest.class))).thenReturn(dataHelper.gameRequestDto());

        service.calculateScore(dataHelper.gameRequestDto(), dataHelper.gameMoveRequest());

        verify(service, times(1))
                .calculateScore(dataHelper.gameRequestDto(), dataHelper.gameMoveRequest());
    }
}
