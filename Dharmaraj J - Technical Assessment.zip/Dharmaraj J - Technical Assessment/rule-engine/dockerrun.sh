docker build -t ruleengine .
docker run -p8083:8083 ruleengine