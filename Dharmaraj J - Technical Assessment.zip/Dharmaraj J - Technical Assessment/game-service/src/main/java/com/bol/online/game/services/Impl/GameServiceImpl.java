package com.bol.online.game.services.Impl;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.exceptions.GameNotFoundException;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.mappers.GameMapper;
import com.bol.online.game.core.utils.GameHelper;
import com.bol.online.game.repositories.GameRepository;
import com.bol.online.game.services.GameService;
import org.mapstruct.factory.Mappers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

/**
 * @author Dharmaraj J
 * GameServiceImpl - To accomodate logic for Game Entity manipulation
 */
@Service
public class GameServiceImpl implements GameService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GameServiceImpl.class);

    @Autowired
    private GameRepository repository;

    @Autowired
    GameHelper gameHelper;

    GameMapper gameMapper = Mappers.getMapper(GameMapper.class);


    @Override
    public GameEntity start(GameEntity gameEntity) {
        LOGGER.info("Creating game against players");
        return create(gameEntity);
    }

    @Override
    public GameEntity update(GameRequestDto gameRequestDto) {
        LOGGER.debug("Game {} received for updateMove", gameRequestDto.getUuid());

        return  create(gameMapper.requestDtoToEntity(gameRequestDto));
    }

    public GameEntity create(GameEntity gameEntity) {
        LOGGER.debug("Game {} received for Saving/Updating", gameEntity.getUuid());
        return repository.save(gameEntity);
    }

    @Override
    public Optional<GameEntity> getGameById(String gameId) {
        if(LOGGER.isDebugEnabled())
            LOGGER.debug("Game {} received for getGameById", gameId);
        Optional<GameEntity> gameEntity = repository.findByUuid(UUID.fromString(gameId));
        Optional.ofNullable(gameEntity).ifPresentOrElse(game -> {
                    LOGGER.info("Game found for Id - {}", gameId);
                },
                () -> {
                    throw new GameNotFoundException(String.format("Game id [%s] not found", gameId));
                });

        return gameEntity;
    }

    @Override
    public void delete(String gameId) {

        Optional<GameEntity> gameEntity = getGameById(gameId);
        Optional.ofNullable(gameEntity).ifPresent(game -> {
                    repository.delete(game.get());
                });

    }


}
