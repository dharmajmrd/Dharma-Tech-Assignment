package com.bol.online.game.services;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.request.GameRequestDto;

import java.util.Optional;

/**
 *
 * @author Dharmaraj J
 * Game - Service Layer
 *
 */
public interface GameService {
    GameEntity update(GameRequestDto request);
    GameEntity start(GameEntity gameEntity);
    Optional<GameEntity> getGameById(String gameId);
    void delete(String gameId);
}
