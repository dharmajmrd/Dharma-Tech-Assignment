package com.bol.online.game.controller;


import com.bol.online.game.business.GameBusiness;
import com.bol.online.game.core.dto.request.GamePlayRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.dto.response.GameStartResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.bol.online.game.core.utils.Constants.*;


@RestController
@RequestMapping(GAME_BASE_URL)
@CrossOrigin(origins = "http://localhost:3000")
public class GameController {

    private static final Logger logger = LoggerFactory.getLogger(GameController.class);

    @Autowired
    private GameBusiness business;

    @GetMapping(GAME_PLAY_URL)
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "API to start the game",
            description = "Fetch the game for the given Game Id and ready for play")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation")
    })
    public ResponseEntity<GameResponseDto> gamePlay(@Valid GamePlayRequest gamePlayRequest) {
        logger.debug("GamePlayRequest received : {}", gamePlayRequest);
        return ResponseEntity.ok(business.getGameById(gamePlayRequest.getUuid()));
    }

    @PostMapping(GAME_START_URL)
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Game play screen API",
            description = "Initialise game board with player details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation")
    })
    public ResponseEntity<GameStartResponse> start(@Valid @RequestBody GameStartRequest gameStartRequest) {
        logger.debug("GameStartRequest received : {}", gameStartRequest);
        return ResponseEntity.ok(business.start(gameStartRequest));
    }

    @PostMapping(GAME_MOVE_URL)
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Game Move API",
            description = "Api to capture the game movement")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation")
    })
    public ResponseEntity<GameResponseDto> updateMove(@Valid @RequestBody GameRequestDto requestDto) {
        logger.debug("GameMoveRequest received : {}", requestDto);
        return ResponseEntity.ok(business.update(requestDto));
    }

    @GetMapping(GAME_GET_URL+UUID_PATH)
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Fetch Game",
            description = "fetches the game and their data from data source")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful operation")
    })
    public ResponseEntity<GameResponseDto> getGameById(@PathVariable("uuid") String uuid) {
        logger.debug("Game id received : {}", uuid);
        return ResponseEntity.ok(business.getGameById(uuid));
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(
            summary = "Delete Game",
            description = "Delete Game by UUID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "successfully Deleted")
    })
    public ResponseEntity<Void> delete(String gameId) {
        business.delete(gameId);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
}
