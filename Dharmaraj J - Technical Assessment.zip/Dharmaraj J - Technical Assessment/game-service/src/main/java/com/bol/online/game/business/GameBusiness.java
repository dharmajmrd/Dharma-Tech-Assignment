package com.bol.online.game.business;

import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.dto.response.GameStartResponse;
import com.bol.online.game.core.mappers.GameMapper;
import com.bol.online.game.core.mappers.GameStartResponseMapper;
import com.bol.online.game.core.mappers.PlayerMapper;
import com.bol.online.game.core.utils.GameHelper;
import com.bol.online.game.services.GameService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Contains mappers
 */
@Component
public class GameBusiness {

    private static final Logger logger = LoggerFactory.getLogger(GameBusiness.class);

    @Autowired
    private GameService service;

    @Autowired
    private GameMapper gameMapper;

    @Autowired
    private PlayerMapper playerMapper;

    @Autowired
    private GameStartResponseMapper gameStartResponseMapper;

    @Autowired
    GameHelper gameHelper;


    public GameStartResponse start(GameStartRequest request) {
        logger.debug("GameStartRequest {} received in business for start", request);
        return gameStartResponseMapper.gameStartResponseFromGameEntity(service
                .start(gameMapper.prepareGameEntity(request,gameHelper.getInitialBoard())));
    }

    public GameResponseDto getGameById(String uuid) {
        logger.debug("UUID {} received in business for getGameById", uuid);
        return gameMapper.gameResponseFromGameEntity(service.getGameById(uuid).orElse(null));
    }

    public GameResponseDto update(GameRequestDto gameRequestDto) {
        logger.debug("GameMoveRequest {} received in business for updateMove", gameRequestDto);
        return gameMapper.gameResponseFromGameEntity(service.update(gameRequestDto));
    }

    public void delete(String gameId) {
        service.delete(gameId);
    }
}
