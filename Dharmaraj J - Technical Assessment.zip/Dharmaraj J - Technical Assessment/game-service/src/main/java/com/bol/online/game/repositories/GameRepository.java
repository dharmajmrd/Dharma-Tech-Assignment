package com.bol.online.game.repositories;

import com.bol.online.game.core.dto.entities.GameEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.locks.StampedLock;


/**
 * @author Dharmaraj J
 * Using Mongo DB for the benefits of Performance and Higher availabilities
 * It is document based and the design is simple and not complicated interms of joins
 */
public interface GameRepository extends MongoRepository<GameEntity,UUID> {

    Optional<GameEntity> findByUuid(UUID id);

}
