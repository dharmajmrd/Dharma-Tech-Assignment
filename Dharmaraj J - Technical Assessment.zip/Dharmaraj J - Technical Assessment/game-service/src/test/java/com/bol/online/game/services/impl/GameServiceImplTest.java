package com.bol.online.game.services.impl;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.dto.exceptions.GameNotFoundException;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.utils.DataHelper;
import com.bol.online.game.services.Impl.GameServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GameServiceImplTest {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private GameServiceImpl gameService;

    @Test
    public void testStart() {
        when(gameService.start(any(GameEntity.class)))
                .thenReturn(dataHelper.gameEntity());

        GameEntity gameEntity = gameService.start(dataHelper.gameEntity());

        assertEquals(dataHelper.gameEntity(), gameEntity);
        verify(gameService, times(1))
                .start(dataHelper.gameEntity());
    }

    @Test
    public void testUpdateMove() {
        when(gameService.update(any(GameRequestDto.class)))
                .thenReturn(dataHelper.gameEntity());

        GameEntity gameEntity = gameService.update(dataHelper.gameRequestDto());

        assertEquals(dataHelper.gameEntity(), gameEntity);
        verify(gameService, times(1))
                .update(dataHelper.gameRequestDto());
    }

    @Test
    public void testCreate() {
        when(gameService.create(any(GameEntity.class)))
                .thenReturn(dataHelper.gameEntity());

        GameEntity gameEntity = gameService.create(dataHelper.gameEntity());

        assertEquals(dataHelper.gameEntity(), gameEntity);
        verify(gameService, times(1))
                .create(dataHelper.gameEntity());
    }

    @Test
    public void testGetGameById() {
        when(gameService.getGameById(anyString()))
                .thenReturn(Optional.of(dataHelper.gameEntity()));

        Optional<GameEntity> gameEntity = gameService.getGameById(DataHelper.GAME_UUID.toString());

        assertEquals(dataHelper.gameEntity(), gameEntity.get());
        verify(gameService, times(1))
                .getGameById(DataHelper.GAME_UUID.toString());
    }

    @Test
    public void testGetGameByIdGameNotFoundException() {
        when(gameService.getGameById(anyString()))
                .thenThrow(new GameNotFoundException());
        assertThrows(GameNotFoundException.class, () ->
            gameService.getGameById(DataHelper.GAME_UUID.toString())
        );
    }

    @Test
    public void testDelete() {

        String gameId = UUID.randomUUID().toString();
        doNothing().when(gameService).delete(gameId);

        gameService.delete(gameId);

        verify(gameService, times(1)).delete(gameId);
    }
}
