package com.bol.online.game.controller;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GamePlayRequest;
import com.bol.online.game.core.dto.request.GameRequestDto;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.utils.DataHelper;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class GameControllerUT {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private GameController gameController;

    @Test
    public void testVerifyGamePlay() {
        when(gameController.gamePlay(any(GamePlayRequest.class)))
                .thenReturn(ResponseEntity.ok(dataHelper.gameResponse()));

        gameController.gamePlay(dataHelper.gamePlayRequest());

        verify(gameController, times(1))
                .gamePlay(dataHelper.gamePlayRequest());
    }

    @Test
    public void testVerifyStart() {
        when(gameController.start(any(GameStartRequest.class)))
                .thenReturn(ResponseEntity.ok(dataHelper.gameStartResponse()));

        gameController.start(dataHelper.gameStartRequest());

        verify(gameController, times(1))
                .start(dataHelper.gameStartRequest());
    }

    @Test
    public void testVerifyUpdateMove() {
        when(gameController.updateMove(any(GameRequestDto.class)))
                .thenReturn(ResponseEntity.ok(dataHelper.gameResponse()));

        gameController.updateMove(dataHelper.gameRequestDto());

        verify(gameController, times(1))
                .updateMove(dataHelper.gameRequestDto());
    }

    @Test
    public void testVerifyGetGame() {
        when(gameController.getGameById(anyString()))
                .thenReturn(ResponseEntity.ok(dataHelper.gameResponse()));

        gameController.getGameById(DataHelper.GAME_UUID.toString());

        verify(gameController, times(1))
                .getGameById(DataHelper.GAME_UUID.toString());
    }
}
