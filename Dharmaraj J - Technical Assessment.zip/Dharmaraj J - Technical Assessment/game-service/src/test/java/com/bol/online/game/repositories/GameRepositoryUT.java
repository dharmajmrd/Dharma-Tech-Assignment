package com.bol.online.game.repositories;

import com.bol.online.game.core.dto.entities.GameEntity;
import com.bol.online.game.core.utils.DataHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.AutoConfigureDataMongo;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@SpringBootTest
public class GameRepositoryUT {

    private final DataHelper dataHelper = new DataHelper();

    @Autowired
    private GameRepository gameRepository1;

    @Mock
    private GameRepository gameRepository;

    @Test
    public void testSave() {
        when(gameRepository.save(any(GameEntity.class)))
                .thenReturn(dataHelper.gameEntity());

        GameEntity gameEntity = gameRepository.save(dataHelper.gameEntity());

        Assertions.assertEquals(dataHelper.gameEntity(), gameEntity);
        verify(gameRepository, times(1))
                .save(dataHelper.gameEntity());
    }

    @Test
    public void testSave1() {

        GameEntity gameEntity = gameRepository1.save(dataHelper.gameEntity());

        Assertions.assertEquals(dataHelper.gameEntity(), gameEntity);

    }

    @Test
    public void testFindById() {
        when(gameRepository.findById(any(UUID.class)))
                .thenReturn(Optional.of(dataHelper.gameEntity()));

        Optional<GameEntity> gameEntity = gameRepository.findById(DataHelper.GAME_UUID);

        Assertions.assertEquals(dataHelper.gameEntity(), gameEntity.get());
        verify(gameRepository, times(1))
                .findById(DataHelper.GAME_UUID);
    }

    @Test
    public void testFindById1() {

        gameRepository1.save(dataHelper.gameEntity());
        Optional<GameEntity> gameEntity = gameRepository1.findByUuid(DataHelper.GAME_UUID);

        Assertions.assertEquals(dataHelper.gameEntity(), gameEntity.get());
    }
}
