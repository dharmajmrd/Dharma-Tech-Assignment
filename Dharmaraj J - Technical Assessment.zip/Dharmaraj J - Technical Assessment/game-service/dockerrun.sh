docker build -t gameservice .
docker run -p8081:8081 gameservice