docker build -t playerservice .
docker run -p8082:8082 playerservice