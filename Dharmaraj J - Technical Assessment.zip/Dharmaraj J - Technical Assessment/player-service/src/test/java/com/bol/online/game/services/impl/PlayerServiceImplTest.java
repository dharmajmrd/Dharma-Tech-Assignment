package com.bol.online.game.services.impl;

import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.utils.DataHelper;
import com.bol.online.game.services.Impl.PlayerServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayerServiceImplTest {

    private final DataHelper dataHelper = new DataHelper();

    @Mock
    private PlayerServiceImpl playerService;

    @Test
    public void testCreate() {
        when(playerService.create(anyString(), any(PlayerType.class)))
                .thenReturn(dataHelper.firstPlayerEntity());

        PlayerEntity playerEntity = playerService.create(DataHelper.FIRST_PLAYER, PlayerType.FIRST);

        Assertions.assertEquals(dataHelper.firstPlayerEntity(), playerEntity);
        verify(playerService, times(1))
                .create(DataHelper.FIRST_PLAYER, PlayerType.FIRST);
    }
}
