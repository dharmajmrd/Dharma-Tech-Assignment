package com.bol.online.game.business;

import com.bol.online.game.core.dto.request.PlayerRequestDto;
import com.bol.online.game.core.dto.response.PlayerResponseDto;
import com.bol.online.game.core.mappers.PlayerResponseMapper;
import com.bol.online.game.services.PlayerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GameBusiness {

    private static final Logger logger = LoggerFactory.getLogger(GameBusiness.class);

    @Autowired
    private PlayerService service;

    @Autowired
    private PlayerResponseMapper playerResponseMapper;



    public PlayerResponseDto create(PlayerRequestDto playerRequestDto) {
        logger.debug("GameStartRequest {} received in business for start", playerRequestDto);
        return playerResponseMapper.entityToDto(service
                .create(playerRequestDto.getName(), playerRequestDto.getPlayerType()));
    }

}
