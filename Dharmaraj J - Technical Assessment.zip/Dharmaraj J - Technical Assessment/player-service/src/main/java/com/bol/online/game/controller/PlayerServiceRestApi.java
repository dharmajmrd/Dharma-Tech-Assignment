package com.bol.online.game.controller;


import com.bol.online.game.business.GameBusiness;
import com.bol.online.game.core.dto.request.PlayerRequestDto;
import com.bol.online.game.core.dto.response.PlayerResponseDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.bol.online.game.core.utils.Constants.*;


@RestController
@RequestMapping(PLAYER_SERVICE_BASE_URL)
@CrossOrigin(origins = "http://localhost:3000")
public class PlayerServiceRestApi {

    private static final Logger logger = LoggerFactory.getLogger(PlayerServiceRestApi.class);

    @Autowired
    private GameBusiness business;

    @PostMapping(PLAYER_CREATE_URL)
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "API to create Players",
            description = "This API creates Players to start the game")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "successful created")
    })
    public ResponseEntity<PlayerResponseDto> create(@Valid @RequestBody PlayerRequestDto playerRequestDto) {
        logger.debug("GamePlayRequest received : {}", playerRequestDto);
        return ResponseEntity.ok(business.create(playerRequestDto));
    }
}
