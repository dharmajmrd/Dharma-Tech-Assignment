package com.bol.online.game.services;

import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.enums.PlayerType;

public interface PlayerService {
    PlayerEntity create(String playerName, PlayerType playerType);
}
