package com.bol.online.game.services.Impl;


import com.bol.online.game.core.dto.entities.PlayerEntity;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.repositories.PlayerRepository;
import com.bol.online.game.services.PlayerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * @author Dharmaraj J
 * @version 1.0
 */
@Service
public class PlayerServiceImpl implements PlayerService {

    private static final Logger logger = LoggerFactory.getLogger(PlayerServiceImpl.class);

    @Autowired
    private PlayerRepository repository;

    @Override
    public PlayerEntity create(String playerName, PlayerType playerType) {
        logger.debug("Creating player against name {}, with type {}", playerName, playerType);
        return repository.save(PlayerEntity
                .builder()
                .uuid(UUID.randomUUID())
                .name(playerName)
                .playerType(playerType)
                .build());
    }
}