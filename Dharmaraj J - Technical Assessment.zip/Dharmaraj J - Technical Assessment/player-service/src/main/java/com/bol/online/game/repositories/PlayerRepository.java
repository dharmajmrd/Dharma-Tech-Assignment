package com.bol.online.game.repositories;

import com.bol.online.game.core.dto.entities.PlayerEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
import java.util.concurrent.locks.StampedLock;

/**
 *
 * @author Dharmaraj J
 * @version 1.0
 *
 */
@Repository
public interface PlayerRepository extends MongoRepository<PlayerEntity,UUID> {

}
