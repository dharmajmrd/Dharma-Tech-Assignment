package com.bol.online.game.exception;

import com.bol.online.game.core.dto.exceptions.MancalaException;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Handle the exceptions received from different microservices
 */
public class ResponseErrorHandlerImpl extends DefaultResponseErrorHandler {

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(response.getBody()))) {
            String httpBodyResponse = reader.lines().collect(Collectors.joining(""));

            JsonParser springParser = JsonParserFactory.getJsonParser();
            Map<String, Object> map = springParser.parseMap(httpBodyResponse);

            throw new MancalaException(map.getOrDefault("errorCode","417").toString(), map.getOrDefault("errorMessage","Expectations Failed").toString());
        }

    }
}
