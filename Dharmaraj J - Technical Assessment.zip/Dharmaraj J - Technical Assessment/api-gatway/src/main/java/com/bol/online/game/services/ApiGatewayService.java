package com.bol.online.game.services;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.dto.response.GameStartResponse;

public interface ApiGatewayService {

    GameStartResponse start(GameStartRequest gameStartRequest);
    GameResponseDto updateMove(GameMoveRequest request);
    GameResponseDto getGameById(String gameId);
    void delete(String gameId);

}
