package com.bol.online.game.controller;


import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GamePlayRequest;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.dto.response.GameStartResponse;
import com.bol.online.game.services.ApiGatewayService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.bol.online.game.utils.Constants.*;

/**
 * This is the gateway api for the clients.
 * All the Requests should be routed via this gateway only
 */
@RestController
@RequestMapping(GAME_BASE_URL)
@CrossOrigin(origins = "http://localhost:3000")
public class ApiGatewayRestApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApiGatewayRestApi.class);

    @Autowired
    private ApiGatewayService service;

    /**
     * Initialise the board once users are ready
     * @param gamePlayRequest
     * @return
     */
    @GetMapping(GAME_PLAY_URL)
    @ResponseStatus(HttpStatus.OK)
    @Operation(
            summary = "Game Play API",
            description = "Fetch the game to start the play")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Game Fetched Successfully")
    })
    public ResponseEntity<GameResponseDto> gamePlay(@Valid GamePlayRequest gamePlayRequest) {
        LOGGER.debug("GamePlayRequest received : {}", gamePlayRequest);
        return ResponseEntity.ok(service.getGameById(gamePlayRequest.getUuid()));
    }

    /**
     * Initialise the game once players are ready
     * @param gameStartRequest
     * @return
     */
    @PostMapping(GAME_START_URL)
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Game play screen API",
            description = "Initialize the game")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Game fetched successfully")
    })
    public ResponseEntity<GameStartResponse> start(@Valid @RequestBody GameStartRequest gameStartRequest) {
        LOGGER.debug("GameStartRequest received : {}", gameStartRequest);
        return ResponseEntity.ok(service.start(gameStartRequest));
    }

    /**
     * Track move for every play
     * @param moveRequest
     * @return
     */
    @PutMapping(GAME_MOVE_URL)
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Api to track moves",
            description = "Persist the game entity for every move")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Game Saved successfully")
    })
    public ResponseEntity<GameResponseDto> updateMove(@Valid @RequestBody GameMoveRequest moveRequest) {
        LOGGER.debug("GameMoveRequest received : {}", moveRequest);
        return ResponseEntity.ok(service.updateMove(moveRequest));
    }

    /**
     * This Apis is to delete the game once GUI is built
     * @param uuid
     * @return
     */
    @DeleteMapping(GAME_DELETE_URL)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(
            summary = "Delete Game",
            description = "Delete the game once game ends")
    @ApiResponses(value = {
                @ApiResponse(responseCode = "200", description = "Game deleted successfully")
    })
    public ResponseEntity<Void> delete(@PathVariable("uuid") String uuid) {
        service.delete(uuid);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
}
