package com.bol.online.game.controller.advice;

import com.bol.online.game.core.dto.exceptions.MancalaException;
import com.bol.online.game.core.dto.response.ResponseError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Optional;

/**
 * Transform the exception into response model
 */
@RestControllerAdvice
public class ControllerAdvice {

    private static final Logger logger = LoggerFactory.getLogger(ControllerAdvice.class);

    @ExceptionHandler(value
            = MancalaException.class)
    public ResponseEntity<ResponseError> handleException(
            MancalaException e) {
        String error = Optional.ofNullable(e.getMessage()).orElse(e.getClass().getName())
                + " [Internal server exception! => (IllegalArgumentException)]";
        ResponseError errorResponse = ResponseError.builder()
                .detailedMessage(e.getErrorMessage())
                .errorCode(Integer.valueOf(e.getErrorCode()))
                .errorMessage(e.getMessage()).build();
        logger.error("Response error created : {}", errorResponse);
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
