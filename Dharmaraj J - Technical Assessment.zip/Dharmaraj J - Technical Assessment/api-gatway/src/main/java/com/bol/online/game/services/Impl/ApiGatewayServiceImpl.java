package com.bol.online.game.services.Impl;

import com.bol.online.game.config.RestClientConfig;
import com.bol.online.game.core.dto.enums.GameStatus;
import com.bol.online.game.core.dto.enums.PlayerType;
import com.bol.online.game.core.dto.request.GameMoveRequest;
import com.bol.online.game.core.dto.request.GameStartRequest;
import com.bol.online.game.core.dto.request.PlayerRequestDto;
import com.bol.online.game.core.dto.request.RuleRequestWrapper;
import com.bol.online.game.core.dto.response.GameResponseDto;
import com.bol.online.game.core.dto.response.GameStartResponse;
import com.bol.online.game.core.dto.response.PlayerResponse;
import com.bol.online.game.core.mappers.GameMapper;
import com.bol.online.game.exception.ResponseErrorHandlerImpl;
import com.bol.online.game.services.ApiGatewayService;
import org.mapstruct.factory.Mappers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Objects;
import java.util.UUID;

import static com.bol.online.game.core.utils.Constants.*;

/**
 * Gateway service layer
 * TODO: move  hardcoded urls to properties file
 */
@Service
public class ApiGatewayServiceImpl implements ApiGatewayService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApiGatewayServiceImpl.class);

    @Autowired
    RestClientConfig restClientConfig;

    GameMapper gameMapper = Mappers.getMapper(GameMapper.class);


    /**
     *
     * @param gameStartRequest
     * Contains Player Info
     * @return
     */
    @Override
    public GameStartResponse start(GameStartRequest gameStartRequest) {
        RestTemplate restTemplate = restClientConfig.getRestTemplate();
        StringBuilder GAME_START = new StringBuilder("http://localhost:8082").append(GAME_BASE_URL).append(GAME_START_URL);
        try {
            createUser(gameStartRequest, restTemplate);
            URI uri1 = new URI(GAME_START.toString());
            ResponseEntity<GameStartResponse> gs1 = restTemplate.postForEntity(uri1, gameStartRequest, GameStartResponse.class);
            return gs1.getBody();

        }catch (URISyntaxException e) {
            LOGGER.error("Exception while calling {}",GAME_START);
            throw new RuntimeException(e);
        }
    }

    private void createUser(GameStartRequest gameStartRequest, RestTemplate restTemplate) throws URISyntaxException {

        StringBuilder PLAYER_CREATE = new StringBuilder("http://localhost:8081").append(PLAYER_SERVICE_BASE_URL).append(PLAYER_CREATE_URL);
        URI uri = new URI(PLAYER_CREATE.toString());


        PlayerRequestDto playerRequestDto1 = PlayerRequestDto.builder()
                .name(gameStartRequest.getFirstPlayer().getName())
                .playerType(PlayerType.FIRST)
                .uuid(UUID.randomUUID())
                .build();

        PlayerRequestDto playerRequestDto2 = PlayerRequestDto.builder()
                .name(gameStartRequest.getSecondPlayer().getName())
                .playerType(PlayerType.SECOND)
                .uuid(UUID.randomUUID())
                .build();

        /**
         * In RealTime application, Make single request for player creation
         */
        ResponseEntity<PlayerResponse> p1 = restTemplate.postForEntity(uri, playerRequestDto1, PlayerResponse.class);

        if(Objects.nonNull(p1.getBody())){
            LOGGER.info("Player1 Created Successfully");
        }
        ResponseEntity<PlayerResponse> p2 = restTemplate.postForEntity(uri, playerRequestDto2, PlayerResponse.class);
        if(Objects.nonNull(p2.getBody())){
            LOGGER.info("Player2 Created Successfully");
        }
    }

    @Override
    public GameResponseDto updateMove(GameMoveRequest request) {

        RestTemplate restTemplate = restClientConfig.getRestTemplate();
        try {

            StringBuilder GAME_PLAY = new StringBuilder("http://localhost:8082").append(GAME_BASE_URL).append(GAME_MOVE_URL);
            StringBuilder RULE_VALIDATE = new StringBuilder("http://localhost:8083").append(RULE_ENGINE_BASE_URL).append(RULE_VALIDATE_MOVE);
            URI uri = new URI(GAME_PLAY.toString());
            URI uri1 = new URI(RULE_VALIDATE.toString());

            GameResponseDto gameResponse = getGameById(request.getUuid());

            gameResponse.setStatus(GameStatus.PROGRESS);

            RuleRequestWrapper ruleRequestWrapper = RuleRequestWrapper.builder()
                    .gameMoveRequest(request)
                    .gameRequestDto(gameMapper.responseDtoToRequestDto(gameResponse))
                    .build();


            ResponseEntity<GameResponseDto> ruleEngineGameResponseDto = restTemplate.postForEntity(uri1, ruleRequestWrapper, GameResponseDto.class);

            ResponseEntity<GameResponseDto> result = restTemplate.postForEntity(uri, gameMapper.responseDtoToRequestDto(ruleEngineGameResponseDto.getBody()), GameResponseDto.class);

            return result.getBody();

        }catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public GameResponseDto getGameById(String gameId) {

        RestTemplate restTemplate = restClientConfig.getRestTemplate();
        restTemplate.setErrorHandler(new ResponseErrorHandlerImpl());
        try {

            StringBuilder GAME_GET = new StringBuilder("http://localhost:8082").append(GAME_BASE_URL).append(GAME_GET_URL).append("/");
            URI uri = new URI(GAME_GET.append(gameId).toString());

            ResponseEntity<GameResponseDto> result = restTemplate.getForEntity(uri, GameResponseDto.class);

            return result.getBody();

        }catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void delete(String gameId) {

        RestTemplate restTemplate = restClientConfig.getRestTemplate();
        try {

            StringBuilder GAME_DELETE = new StringBuilder("http://localhost:8082").append(GAME_BASE_URL).append(GAME_DELETE_URL);
            URI uri = new URI(GAME_DELETE +gameId);


           restTemplate.delete(uri);


        }catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

    }
}
