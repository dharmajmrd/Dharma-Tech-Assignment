package com.bol.online.game.utils;

public class Constants {

    public static final String GAME_BASE_URL = "/game";
    public static final String GAME_GET_URL = "/{uuid}";
    public static final String GAME_START_URL = "/start";
    public static final String GAME_PLAY_URL = "/play" + GAME_GET_URL;
    public static final String GAME_MOVE_URL = "/move";

    public static final String GAME_DELETE_URL = "/delete/{uuid}";


    private Constants() {

    }
}
