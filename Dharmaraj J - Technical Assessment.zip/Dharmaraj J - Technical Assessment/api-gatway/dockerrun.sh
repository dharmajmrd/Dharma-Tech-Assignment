docker build -t apigateway .
docker run -p8080:8080 apigateway